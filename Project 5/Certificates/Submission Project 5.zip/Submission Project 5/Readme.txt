For running the python program

Pre-requisites
Python3.x

Open the terminal
type the following script

python .\CertAuth.py ["path_p12_file"] ["path_root_crt"] ["path_subject_crt"] ["passphrase_p12"]

Output:

Each part is shown one below the other in ascending order
